﻿namespace SocApplication.Models
{
    public class TenderProposal
    {
        public int id { get; set; }
        public int drugId { get; set; }
        public string drugName { get; set; }
        public int requestedQuantity { get; set; }
        public string contactEmail { get; set; }
        public DateTime proposalDate { get; set; }
    }
}
