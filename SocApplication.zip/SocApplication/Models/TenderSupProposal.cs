﻿namespace SocApplication.Models
{
    public class TenderSupProposal
    {
        public string SupplierName { get; set; }
        public string SupplierEmail { get; set; }
        public string DrugName { get; set; }
        public int DrugQuantity { get; set; }
        public string Details { get; set; }
        public decimal DrugPrice { get; set; }
    }
}
