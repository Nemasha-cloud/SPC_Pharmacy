﻿namespace SocApplication.Models
{
    public class Staff
    {
        public int id { get; set; }           // Auto-incremented primary key
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string email { get; set; }
        public string password { get; set; }  // In production, store hashed passwords
        public string address { get; set; }
        public string type { get; set; }      // E.g., "admin", "employee", etc.
    }
}
