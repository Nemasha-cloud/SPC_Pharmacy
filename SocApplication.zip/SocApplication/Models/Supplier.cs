﻿namespace SocApplication.Models
{
    public class Supplier
    {
        public int id { get; set; }           // Auto-increment identity column
        public string name { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string suppliedItem { get; set; }
        public string quantity { get; set; }
        public string address { get; set; }
        public bool isApproved { get; set; }
    }
}
