﻿namespace SocApplication.Models
{
    public class StaffLogin
    {
        public string email { get; set; }
        public string password { get; set; }  
    }
}
