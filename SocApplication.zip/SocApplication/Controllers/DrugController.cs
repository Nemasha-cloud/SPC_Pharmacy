﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SocApplication.Models;
using System.Collections.Generic;

namespace SocApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DrugController : ControllerBase
    {
        private readonly string _connectionString;

        public DrugController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("$con");
        }

        // GET: api/drug
        [HttpGet]
        public IActionResult GetDrugs()
        {
            var drugs = new List<Drug>();

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "SELECT id, name, description, quantity, price FROM Drug";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                drugs.Add(new Drug
                {
                    id = reader.GetInt32(0),
                    name = reader.GetString(1),
                    description = reader.GetString(2),
                    quantity = reader.GetInt32(3),
                    price = reader.GetDecimal(4)
                });
            }

            return Ok(drugs);
        }

        // GET: api/drug/{id}
        [HttpGet("{id}")]
        public IActionResult GetDrugById(int id)
        {
            Drug drug = null;

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "SELECT id, name, description, quantity, price FROM Drug WHERE id = @id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", id);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                drug = new Drug
                {
                    id = reader.GetInt32(0),
                    name = reader.GetString(1),
                    description = reader.GetString(2),
                    quantity = reader.GetInt32(3),
                    price = reader.GetDecimal(4)
                };
            }

            if (drug == null)
                return NotFound($"Drug with ID {id} not found.");

            return Ok(drug);
        }

        // POST: api/drug
        [HttpPost]
        public IActionResult AddDrug([FromBody] Drug drug)
        {
            if (drug == null)
                return BadRequest("Invalid drug data.");

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "INSERT INTO Drug (name, description, quantity, price) " +
                         "VALUES (@name, @description, @quantity, @price)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@name", drug.name);
            cmd.Parameters.AddWithValue("@description", drug.description);
            cmd.Parameters.AddWithValue("@quantity", drug.quantity);
            cmd.Parameters.AddWithValue("@price", drug.price);

            int rowsAffected = cmd.ExecuteNonQuery();

            return rowsAffected > 0 ? Ok("Drug added successfully.")
                                    : StatusCode(500, "Error adding drug.");
        }

        // PUT: api/drug
        [HttpPut]
        public IActionResult UpdateDrug([FromBody] Drug drug)
        {
            if (drug == null || drug.id <= 0)
                return BadRequest("Invalid drug data.");

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "UPDATE Drug SET name = @name, description = @description, quantity = @quantity, price = @price " +
                         "WHERE id = @id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@name", drug.name);
            cmd.Parameters.AddWithValue("@description", drug.description);
            cmd.Parameters.AddWithValue("@quantity", drug.quantity);
            cmd.Parameters.AddWithValue("@price", drug.price);
            cmd.Parameters.AddWithValue("@id", drug.id);

            int rowsAffected = cmd.ExecuteNonQuery();

            return rowsAffected > 0 ? Ok("Drug updated successfully.")
                                    : StatusCode(500, "Error updating drug.");
        }

        // DELETE: api/drug/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteDrug(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "DELETE FROM Drug WHERE id = @id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", id);
            int rowsAffected = cmd.ExecuteNonQuery();

            return rowsAffected > 0 ? Ok("Drug deleted successfully.")
                                    : NotFound($"Drug with ID {id} not found.");
        }
    }
}
