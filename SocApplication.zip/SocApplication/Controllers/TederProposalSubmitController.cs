﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using SocApplication.Models;

namespace SocApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TederProposalSubmitController : ControllerBase
    {

        private readonly string _connectionString;
        public TederProposalSubmitController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("$con");
        }

        [HttpPost]
        public async Task<IActionResult> SubmitTenderProposal([FromBody] TenderSupProposal proposal)
        {
            if (proposal == null)
            {
                return BadRequest("Invalid proposal data.");
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    await conn.OpenAsync();
                    string query = "INSERT INTO TenderProposalSup (SupplierName, SupplierEmail, DrugName, DrugQuantity, Details, DrugPrice) VALUES (@SupplierName, @SupplierEmail, @DrugName, @DrugQuantity, @Details, @DrugPrice)";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@SupplierName", proposal.SupplierName);
                        cmd.Parameters.AddWithValue("@SupplierEmail", proposal.SupplierEmail);
                        cmd.Parameters.AddWithValue("@DrugName", proposal.DrugName);
                        cmd.Parameters.AddWithValue("@DrugQuantity", proposal.DrugQuantity);
                        cmd.Parameters.AddWithValue("@Details", proposal.Details ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("@DrugPrice", proposal.DrugPrice);

                        await cmd.ExecuteNonQueryAsync();
                    }
                }
                return Ok(new { message = "Tender proposal submitted successfully!" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    
    
         // GET: View tender proposals for the logged-in supplier
        [HttpGet("{supplierEmail}")]
        public async Task<IActionResult> GetTenderProposalsBySupplier(string supplierEmail)
        {
            List<TenderSupProposal> proposals = new List<TenderSupProposal>();

            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    await conn.OpenAsync();
                    string query = "SELECT * FROM TenderProposalSup WHERE SupplierEmail = @SupplierEmail";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@SupplierEmail", supplierEmail);

                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                proposals.Add(new TenderSupProposal
                                {
                                    SupplierName = reader["SupplierName"].ToString(),
                                    SupplierEmail = reader["SupplierEmail"].ToString(),
                                    DrugName = reader["DrugName"].ToString(),
                                    DrugQuantity = Convert.ToInt32(reader["DrugQuantity"]),
                                    Details = reader["Details"]?.ToString(),
                                    DrugPrice = Convert.ToDecimal(reader["DrugPrice"])
                                });
                            }
                        }
                    }
                }
                return Ok(proposals);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        // GET: Get all tender proposals
        [HttpGet("all")]
        public async Task<IActionResult> GetAllTenderProposals()
        {
            List<TenderSupProposal> proposals = new List<TenderSupProposal>();

            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    await conn.OpenAsync();
                    string query = "SELECT * FROM TenderProposalSup";

                    using (SqlCommand cmd = new SqlCommand(query, conn))
                    {
                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            while (await reader.ReadAsync())
                            {
                                proposals.Add(new TenderSupProposal
                                {
                                    SupplierName = reader["SupplierName"].ToString(),
                                    SupplierEmail = reader["SupplierEmail"].ToString(),
                                    DrugName = reader["DrugName"].ToString(),
                                    DrugQuantity = Convert.ToInt32(reader["DrugQuantity"]),
                                    Details = reader["Details"]?.ToString(),
                                    DrugPrice = Convert.ToDecimal(reader["DrugPrice"])
                                });
                            }
                        }
                    }
                }
                return Ok(proposals);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
    }
}
