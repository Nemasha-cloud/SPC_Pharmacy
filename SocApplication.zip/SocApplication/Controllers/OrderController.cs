﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using SocApplication.Models;
using System.Collections.Generic;

namespace SocApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        private readonly string _connectionString;

        public OrderController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("$con");
        }

        // GET: api/order
        [HttpGet]
        public IActionResult GetOrders()
        {
            var orders = new List<Order>();

            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "SELECT Id, DrugId, DrugName, Quantity FROM Orders";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                orders.Add(new Order
                {
                    Id = reader.GetInt32(0),
                    DrugId = reader.GetInt32(1),
                    DrugName = reader.GetString(2),
                    Quantity = reader.GetInt32(3)
                });
            }

            return Ok(orders);
        }

        // GET: api/order/{id}
        [HttpGet("{id}")]
        public IActionResult GetOrderById(int id)
        {
            Order order = null;

            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "SELECT Id, DrugId, DrugName, Quantity FROM Orders WHERE Id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                order = new Order
                {
                    Id = reader.GetInt32(0),
                    DrugId = reader.GetInt32(1),
                    DrugName = reader.GetString(2),
                    Quantity = reader.GetInt32(3)
                };
            }

            return order != null ? Ok(order) : NotFound("Order not found.");
        }

        // POST: api/order
        [HttpPost]
        public IActionResult PlaceOrder([FromBody] Order order)
        {
            if (order == null || order.Quantity <= 0)
                return BadRequest(new { message = "Invalid order data." });

            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "INSERT INTO Orders (DrugId, DrugName, Quantity) VALUES (@DrugId, @DrugName, @Quantity)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@DrugId", order.DrugId);
            cmd.Parameters.AddWithValue("@DrugName", order.DrugName);
            cmd.Parameters.AddWithValue("@Quantity", order.Quantity);

            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0 ? Ok(new { message = "Order placed successfully" }) : StatusCode(500, "Error placing order.");
        }

        // PUT: api/order
        [HttpPut]
        public IActionResult UpdateOrder([FromBody] Order order)
        {
            if (order == null || order.Id <= 0)
                return BadRequest("Invalid order data.");

            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "UPDATE Orders SET DrugId = @DrugId, DrugName = @DrugName, Quantity = @Quantity WHERE Id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@DrugId", order.DrugId);
            cmd.Parameters.AddWithValue("@DrugName", order.DrugName);
            cmd.Parameters.AddWithValue("@Quantity", order.Quantity);
            cmd.Parameters.AddWithValue("@Id", order.Id);

            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0 ? Ok("Order updated successfully.") : NotFound("Order not found.");
        }

        // DELETE: api/order/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteOrder(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "DELETE FROM Orders WHERE Id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);

            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0 ? Ok("Order deleted successfully.") : NotFound("Order not found.");
        }
    }
}
