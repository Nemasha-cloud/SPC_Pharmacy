﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SocApplication.Models;

namespace SocApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TenderProposalController : ControllerBase
    {
        private readonly string _connectionString;
        public TenderProposalController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("$con");
        }

        // POST: api/tenderproposal
        [HttpPost]
        public IActionResult SubmitProposal([FromBody] TenderProposal proposal)
        {
            if (proposal == null)
                return BadRequest("Invalid proposal data.");

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "INSERT INTO TenderProposal (drugId, drugName, requestedQuantity, contactEmail) " +
                         "VALUES (@drugId, @drugName, @requestedQuantity, @contactEmail)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@drugId", proposal.drugId);
            cmd.Parameters.AddWithValue("@drugName", proposal.drugName);
            cmd.Parameters.AddWithValue("@requestedQuantity", proposal.requestedQuantity);
            cmd.Parameters.AddWithValue("@contactEmail", proposal.contactEmail);

            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0 ? Ok("Tender proposal submitted successfully.")
                                    : StatusCode(500, "Error submitting tender proposal.");
        }

        // GET: api/tenderproposal - Fetch all tender proposals
        [HttpGet]
        public IActionResult GetTenderProposals()
        {
            List<TenderProposal> proposals = new();

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "SELECT id, drugId, drugName, requestedQuantity, contactEmail FROM TenderProposal";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                proposals.Add(new TenderProposal
                {
                    id = reader.GetInt32(0),
                    drugId = reader.GetInt32(1),
                    drugName = reader.GetString(2),
                    requestedQuantity = reader.GetInt32(3),
                    contactEmail = reader.GetString(4)
                });
            }

            return Ok(proposals);
        }
    }
}
