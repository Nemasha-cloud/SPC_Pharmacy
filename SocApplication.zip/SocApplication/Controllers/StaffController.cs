﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using SocApplication.Models;

namespace SocApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StaffController : ControllerBase
    {
        private readonly string _connectionString;

        public StaffController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("$con");
        }

        // POST: api/staff/login
        // Login API: Verifies staff credentials (email & password)
        // POST: api/staff/login
        [HttpPost("login")]
        public IActionResult Login([FromBody] StaffLogin loginInfo)
        {
            if (loginInfo == null || string.IsNullOrEmpty(loginInfo.email) || string.IsNullOrEmpty(loginInfo.password))
                return BadRequest(new { status = "error", message = "Invalid login data." });

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "SELECT id, firstname, lastname, email, address, type, password FROM Staff WHERE email = @Email";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Email", loginInfo.email);

            using var reader = cmd.ExecuteReader();
            if (!reader.Read())
                return Unauthorized(new { status = "error", message = "Invalid email or password." });

            // Check password (not hashed)
            string dbPassword = reader.GetString(6);
            if (dbPassword != loginInfo.password)
                return Unauthorized(new { status = "error", message = "Invalid email or password." });

            // If login is successful
            var staff = new
            {
                id = reader.GetInt32(0),
                firstname = reader.GetString(1),
                lastname = reader.GetString(2),
                email = reader.GetString(3),
                address = reader.GetString(4),
                type = reader.GetString(5) // Staff type (admin, warehouse, etc.)
            };

            return Ok(new { status = "success", message = "Login successful", data = staff });
        }



        // GET: api/staff
        // Retrieves all staff members
        [HttpGet]
        public IActionResult GetStaffs()
        {
            var staffs = new List<Staff>();
            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "SELECT id, firstname, lastname, email, password, address, type FROM Staff";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                staffs.Add(new Staff
                {
                    id = reader.GetInt32(0),
                    firstname = reader.GetString(1),
                    lastname = reader.GetString(2),
                    email = reader.GetString(3),
                    password = reader.GetString(4),
                    address = reader.GetString(5),
                    type = reader.GetString(6)
                });
            }
            return Ok(staffs);
        }

        // GET: api/staff/{id}
        // Retrieves a specific staff member by id
        [HttpGet("{id}")]
        public IActionResult GetStaffById(int id)
        {
            Staff staff = null;
            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "SELECT id, firstname, lastname, email, password, address, type FROM Staff WHERE id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                staff = new Staff
                {
                    id = reader.GetInt32(0),
                    firstname = reader.GetString(1),
                    lastname = reader.GetString(2),
                    email = reader.GetString(3),
                    password = reader.GetString(4),
                    address = reader.GetString(5),
                    type = reader.GetString(6)
                };
            }
            if (staff == null)
                return NotFound("Staff not found.");
            return Ok(staff);
        }

        // POST: api/staff
        // Adds a new staff member (registration)
        [HttpPost]
        public IActionResult AddStaff([FromBody] Staff staff)
        {
            if (staff == null)
                return BadRequest("Invalid staff data.");

            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "INSERT INTO Staff (firstname, lastname, email, password, address, type) " +
                         "VALUES (@Firstname, @Lastname, @Email, @Password, @Address, @Type)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Firstname", staff.firstname);
            cmd.Parameters.AddWithValue("@Lastname", staff.lastname);
            cmd.Parameters.AddWithValue("@Email", staff.email);
            cmd.Parameters.AddWithValue("@Password", staff.password);
            cmd.Parameters.AddWithValue("@Address", staff.address);
            cmd.Parameters.AddWithValue("@Type", staff.type);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0 ? Ok("Staff added successfully.") : StatusCode(500, "Error adding staff.");
        }

        // PUT: api/staff
        // Updates an existing staff member's details
        [HttpPut]
        public IActionResult UpdateStaff([FromBody] Staff staff)
        {
            if (staff == null || staff.id <= 0)
                return BadRequest("Invalid staff data.");

            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "UPDATE Staff SET firstname = @Firstname, lastname = @Lastname, email = @Email, " +
                         "password = @Password, address = @Address, type = @Type WHERE id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Firstname", staff.firstname);
            cmd.Parameters.AddWithValue("@Lastname", staff.lastname);
            cmd.Parameters.AddWithValue("@Email", staff.email);
            cmd.Parameters.AddWithValue("@Password", staff.password);
            cmd.Parameters.AddWithValue("@Address", staff.address);
            cmd.Parameters.AddWithValue("@Type", staff.type);
            cmd.Parameters.AddWithValue("@Id", staff.id);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0 ? Ok("Staff updated successfully.") : StatusCode(500, "Error updating staff.");
        }

        // DELETE: api/staff/{id}
        // Deletes a staff member by id
        [HttpDelete("{id}")]
        public IActionResult DeleteStaff(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "DELETE FROM Staff WHERE id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0 ? Ok("Staff deleted successfully.") : NotFound("Staff not found.");
        }
    }
}
