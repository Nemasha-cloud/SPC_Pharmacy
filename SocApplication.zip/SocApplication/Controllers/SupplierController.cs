﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using SocApplication.Models;
using System.Collections.Generic;

namespace SocApplication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SupplierController : ControllerBase
    {
        private readonly string _connectionString;

        public SupplierController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("$con");
        }

        // GET: api/supplier
        [HttpGet]
        public IActionResult GetSuppliers()
        {
            var suppliers = new List<Supplier>();

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "SELECT id, name, email, password, supplieditem, quantity, address, isApproved FROM Supplier";
            using var cmd = new SqlCommand(sql, conn);
            using var reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                string v = reader.GetString(1);
                suppliers.Add(new Supplier
                {
                    id = reader.GetInt32(0),
                    name = v,
                    email = reader.GetString(2),
                    password = reader.GetString(3),
                    suppliedItem = reader.GetString(4),
                    quantity = reader.GetString(5),
                    address = reader.GetString(6),
                    isApproved = reader.GetBoolean(7)
                });
            }

            return Ok(suppliers);
        }

        // GET: api/supplier/{id}
        [HttpGet("{id}")]
        public IActionResult GetSupplierById(int id)
        {
            Supplier supplier = null;

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "SELECT id, name, email, password, supplieditem, quantity, address FROM Supplier WHERE id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            using var reader = cmd.ExecuteReader();

            if (reader.Read())
            {
                supplier = new Supplier
                {
                    id = reader.GetInt32(0),
                    name = reader.GetString(1),
                    email = reader.GetString(2),
                    password = reader.GetString(3),
                    suppliedItem = reader.GetString(4),
                    quantity = reader.GetString(5),
                    address = reader.GetString(6)
                };
            }

            if (supplier == null)
                return NotFound($"Supplier with ID {id} not found.");

            return Ok(supplier);
        }

        // POST: api/supplier
        [HttpPost]
        public IActionResult AddSupplier([FromBody] Supplier supplier)
        {
            if (supplier == null)
                return BadRequest("Invalid supplier data.");

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            // id is auto-generated, so we don't include it in the INSERT statement.
            string sql = "INSERT INTO Supplier (name, email, password, supplieditem, quantity, address) " +
                         "VALUES (@Name, @Email, @Password, @SuppliedItem, @Quantity, @Address)";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Name", supplier.name);
            cmd.Parameters.AddWithValue("@Email", supplier.email);
            cmd.Parameters.AddWithValue("@Password", supplier.password);
            cmd.Parameters.AddWithValue("@SuppliedItem", supplier.suppliedItem);
            cmd.Parameters.AddWithValue("@Quantity", supplier.quantity);
            cmd.Parameters.AddWithValue("@Address", supplier.address);

            int rowsAffected = cmd.ExecuteNonQuery();

            return rowsAffected > 0 ? Ok("Supplier added successfully.")
                                    : StatusCode(500, "Error adding supplier.");
        }

        // PUT: api/supplier
        [HttpPut]
        public IActionResult UpdateSupplier([FromBody] Supplier supplier)
        {
            if (supplier == null || supplier.id <= 0)
                return BadRequest("Invalid supplier data.");

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "UPDATE Supplier SET name = @Name, email = @Email, password = @Password, " +
                         "supplieditem = @SuppliedItem, quantity = @Quantity, address = @Address " +
                         "WHERE id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Name", supplier.name);
            cmd.Parameters.AddWithValue("@Email", supplier.email);
            cmd.Parameters.AddWithValue("@Password", supplier.password);
            cmd.Parameters.AddWithValue("@SuppliedItem", supplier.suppliedItem);
            cmd.Parameters.AddWithValue("@Quantity", supplier.quantity);
            cmd.Parameters.AddWithValue("@Address", supplier.address);
            cmd.Parameters.AddWithValue("@Id", supplier.id);

            int rowsAffected = cmd.ExecuteNonQuery();

            return rowsAffected > 0 ? Ok("Supplier updated successfully.")
                                    : StatusCode(500, "Error updating supplier.");
        }

        // DELETE: api/supplier/{id}
        [HttpDelete("{id}")]
        public IActionResult DeleteSupplier(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "DELETE FROM Supplier WHERE id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            int rowsAffected = cmd.ExecuteNonQuery();

            return rowsAffected > 0 ? Ok("Supplier deleted successfully.")
                                    : NotFound($"Supplier with ID {id} not found.");
        }

        // PUT: api/supplier/approve/{id}
        [HttpPut("approve/{id}")]
        public IActionResult ApproveSupplier(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "UPDATE Supplier SET isApproved = 1 WHERE id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0 ? Ok("Supplier approved successfully.")
                                    : NotFound($"Supplier with ID {id} not found.");
        }

        // PUT: api/supplier/unapprove/{id}
        [HttpPut("unapprove/{id}")]
        public IActionResult UnapproveSupplier(int id)
        {
            using var conn = new SqlConnection(_connectionString);
            conn.Open();
            string sql = "UPDATE Supplier SET isApproved = 0 WHERE id = @Id";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Id", id);
            int rowsAffected = cmd.ExecuteNonQuery();
            return rowsAffected > 0 ? Ok("Supplier unapproved successfully.")
                                    : NotFound($"Supplier with ID {id} not found.");
        }


        // POST: api/supplier/login
        [HttpPost("login")]
        public IActionResult LoginSupplier([FromBody] SupplierLogin request)
        {
            if (request == null || string.IsNullOrEmpty(request.Email) || string.IsNullOrEmpty(request.Password))
            {
                return BadRequest("Invalid login data.");
            }

            using var conn = new SqlConnection(_connectionString);
            conn.Open();

            string sql = "SELECT id, name, email, isApproved FROM Supplier WHERE email = @Email AND password = @Password";
            using var cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@Email", request.Email);
            cmd.Parameters.AddWithValue("@Password", request.Password);

            using var reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                var supplier = new
                {
                    id = reader.GetInt32(0),
                    name = reader.GetString(1),
                    email = reader.GetString(2),
                    isApproved = reader.GetBoolean(3)
                };

                if (!supplier.isApproved)
                {
                    return Unauthorized(new { status = "error", message = "Your account is not approved yet." });
                }

                return Ok(new { status = "success", data = supplier });
            }

            return Unauthorized(new { status = "error", message = "Invalid email or password." });
        }



    }
}
