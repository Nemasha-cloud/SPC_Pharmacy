<?php
session_start();

// Check if the supplier is logged in
if (!isset($_SESSION['SupplierID'])) {
    header("Location: supplierLogin.php");
    exit();
}

// Welcome message
$supplierName = $_SESSION['SupplierName'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Supplier Dashboard - SPC</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f8fb;
            color: #333;
        }
        header {
            background-color: #003366;
            color: white;
            padding: 20px 10%;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        header h1 {
            margin: 0;
            font-size: 2.5em;
        }
        header p {
            margin: 5px 0 0;
            font-size: 1.2em;
        }
        nav {
            display: flex;
            justify-content: center;
            background-color: #00509e;
            padding: 10px 0;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 1.1em;
            font-weight: bold;
            transition: color 0.3s;
        }
        nav a:hover {
            color: #ffcc00;
        }
        .container {
            padding: 20px 10%;
        }
        .admin-section {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 20px;
            text-align: center;
        }
        .admin-section h2 {
            color: #003366;
            margin-bottom: 20px;
        }
        .logout {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1em;
            border-radius: 5px;
            cursor: pointer;
            margin: 5px 0;
            transition: background-color 0.3s;
        }
        .logout:hover {
            background-color: #c9302c;
        }
        .card-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background: white;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        }
        .card:hover {
            transform: scale(1.05);
            box-shadow: 0 8px 12px rgba(0, 0, 0, 0.2);
        }
        .card h3 {
            color: #00509e;
            margin-bottom: 10px;
        }
        .card p {
            font-size: 1em;
            margin: 5px 0;
        }
        footer {
            background-color: #003366;
            color: white;
            text-align: center;
            padding: 10px 0;
            margin-top: 20px;
        }
        .admin-section .btn {
                background-color: #00509e;
                color: white;
                border: none;
                padding: 10px 20px;
                font-size: 1em;
                border-radius: 5px;
                cursor: pointer;
                margin: 5px 0;
                display: block;
                width: 20%;
                transition: background-color 0.3s;
            }
            .admin-section .btn:hover {
                background-color: #ffcc00;
                color: #003366;
            }

        /* Modal Styling */
            .modal {
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.5);
                display: flex;
                justify-content: center;
                align-items: center;
            }

            .modal-content {
                background: white;
                padding: 25px;
                width: 40%;
                max-width: 500px;
                border-radius: 10px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
                text-align: left;
                position: relative;
                animation: fadeIn 0.3s ease-in-out;
            }

            @keyframes fadeIn {
                from {
                    opacity: 0;
                    transform: translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .modal h2 {
                color: #003366;
                font-size: 1.8em;
                margin-bottom: 15px;
                text-align: center;
            }

            /* Form Styling */
            .modal-content form {
                display: flex;
                flex-direction: column;
            }

            .modal-content label {
                font-size: 1.1em;
                font-weight: bold;
                color: #333;
                margin-top: 10px;
            }

            .modal-content input,
            .modal-content select,
            .modal-content textarea {
                width: 100%;
                padding: 10px;
                margin-top: 5px;
                border: 1px solid #ccc;
                border-radius: 5px;
                font-size: 1em;
                transition: 0.3s;
            }

            .modal-content input:focus,
            .modal-content select:focus,
            .modal-content textarea:focus {
                border-color: #00509e;
                outline: none;
            }

            /* Buttons */
            .modal-content button {
                background-color: #00509e;
                color: white;
                padding: 12px;
                border: none;
                border-radius: 5px;
                cursor: pointer;
                font-size: 1.1em;
                margin-top: 15px;
                transition: background 0.3s;
            }

            .modal-content button:hover {
                background-color: #ffcc00;
                color: #003366;
            }

            #closeModal {
                background-color: #d9534f;
            }

            #closeModal:hover {
                background-color: #c9302c;
            }

    </style>
</head>
<body>
    <header>
        <h1>State Pharmaceutical Corporation</h1>
        <p>Supplier Dashboard</p>
    </header>
    <nav>
        <a href="home.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="services.php">Services</a>
        <a href="contact.php">Contact</a>
    </nav>
    <div class="container">
        <div class="admin-section">
        <button class="btn">Create Tender Proposal</button>
            <button class="btn" onclick="location.href='logoutsupplier.php'">Logout</button>
            <h2>Welcome, <?php echo htmlspecialchars($supplierName); ?>!</h2>
            <h2>SPC Tender Requests</h2>

            <!-- Placeholder for Tender Cards -->
            <div id="tender-cards" class="card-container">
                <p>Loading tender proposals...</p>
            </div>

            <!-- Table for view tender proposals -->
        </div>
    </div>

        <!-- Modal Structure -->
    <div id="tenderModal" class="modal">
        <div class="modal-content">
            <h2>Submit Tender Proposal</h2>
            <form id="tenderProposalForm">
                <label>Supplier Name:</label>
                <input type="text" id="supplierName" readonly>
                
                <label>Supplier Email:</label>
                <input type="email" id="supplierEmail" readonly>
                
                <label>Drug Name:</label>
                <select id="drugName"></select>

                <label>Quantity:</label>
                <input type="number" id="drugQuantity" required>
                
                <label>Details:</label>
                <textarea id="details"></textarea>
                
                <label>Price:</label>
                <input type="number" id="drugPrice" step="0.01" required>
                
                <button type="submit">Submit</button>
                <button type="button" id="closeModal">Close</button>
            </form>
        </div>
    </div>

    <footer>
        <p>&copy; 2025 State Pharmaceutical Corporation. All rights reserved.</p>
    </footer>

    <script>
        $(document).ready(function() {
            $.ajax({
                url: "https://localhost:7123/api/TenderProposal", // Replace with your actual API endpoint
                method: "GET",
                dataType: "json",
                success: function(data) {
                    var cards = "";
                    if (data.length > 0) {
                        $.each(data, function(index, tender) {
                            cards += `
                                <div class="card">
                                    <h3><strong>Drug Name:</strong>${tender.drugName}</h3>
                                    <p><strong>Drug ID:</strong> ${tender.drugId}</p>
                                    <p><strong>Quantity Requested:</strong> ${tender.requestedQuantity}</p>
                                    <p><strong>Contact Email:</strong> ${tender.contactEmail}</p>
                                </div>
                            `;
                        });
                    } else {
                        cards = "<p>No tender proposals available.</p>";
                    }
                    $("#tender-cards").html(cards);
                },
                error: function() {
                    $("#tender-cards").html("<p>Failed to load tender proposals. Please try again.</p>");
                }
            });
        });
    </script>

<script>
    $(document).ready(function () {
        const supplierName = "<?php echo $_SESSION['SupplierName']; ?>";
        const supplierEmail = "<?php echo $_SESSION['SupplierEmail']; ?>";

        $("#supplierName").val(supplierName);
        $("#supplierEmail").val(supplierEmail);

        // Open Modal
        $(".btn").click(function () {
            $("#tenderModal").show();
            fetchDrugNames();
        });

        // Close Modal
        $("#closeModal").click(function () {
            $("#tenderModal").hide();
        });

        // Fetch Drug Names for Dropdown
        function fetchDrugNames() {
            $.ajax({
                url: "https://localhost:7123/api/TenderProposal", // Update with correct API endpoint
                method: "GET",
                dataType: "json",
                success: function (data) {
                    console.log(data);
                    $("#drugName").empty();
                    $.each(data, function (index, drug) {
                        $("#drugName").append(`<option value="${drug.drugName}">${drug.drugName}</option>`);
                    });
                },
                error: function () {
                    console.log("Failed to fetch drug names.");
                }
            });
        }

        // Submit Tender Proposal Form
        $("#tenderProposalForm").submit(function (event) {
            event.preventDefault();

            let proposalData = {
                supplierName: $("#supplierName").val(),
                supplierEmail: $("#supplierEmail").val(),
                drugName: $("#drugName").val(),
                drugQuantity: $("#drugQuantity").val(),
                details: $("#details").val(),
                drugPrice: $("#drugPrice").val(),
            };

            $.ajax({
                url: "https://localhost:7123/api/TederProposalSubmit",
                method: "POST",
                contentType: "application/json",
                data: JSON.stringify(proposalData),
                success: function (response) {
                    alert(response.message);
                    $("#tenderModal").hide();
                    $("#tenderProposalForm")[0].reset();
                },
                error: function () {
                    alert("Error submitting proposal.");
                }
            });
        });
    });
</script>

</body>
</html>
