<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Panel - Staff Management</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f4f8fb;
      color: #333;
    }
    header {
      background-color: #003366;
      color: white;
      padding: 20px 10%;
      text-align: center;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    header h1 {
      margin: 0;
      font-size: 2.5em;
    }
    nav {
      display: flex;
      justify-content: center;
      background-color: #00509e;
      padding: 10px 0;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    nav a {
      color: white;
      text-decoration: none;
      margin: 0 15px;
      font-size: 1.1em;
      font-weight: bold;
      transition: color 0.3s;
    }
    nav a:hover {
      color: #ffcc00;
    }
    .container {
      padding: 20px 10%;
    }
    h2 {
      color: #003366;
    }
    /* Table styling */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    table, th, td {
      border: 1px solid #ddd;
    }
    th, td {
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #003366;
      color: #fff;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    .btn {
      padding: 5px 10px;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      margin-right: 5px;
    }
    .btn-update {
      background-color: #4CAF50;
      color: white;
    }
    .btn-delete {
      background-color: #f44336;
      color: white;
    }
    /* Modal Styles */
    .modal {
      display: none; /* Hidden by default */
      position: fixed;
      z-index: 2;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.5);
    }
    .modal-content {
      background-color: #fff;
      margin: 10% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 40%;
      border-radius: 10px;
      position: relative;
    }
    .modal-content h2 {
      color: #003366;
      margin-bottom: 15px;
      text-align: center;
    }
    .modal-content .form-group {
      margin-bottom: 15px;
    }
    .modal-content label {
      font-weight: bold;
      display: block;
      margin-bottom: 5px;
    }
    .modal-content input,
    .modal-content select {
      width: 100%;
      padding: 8px;
      box-sizing: border-box;
    }

    .admin-section button {
      width: 20%;
      padding: 10px;
      background-color: #00509e;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 1em;
      cursor: pointer;
      margin-top: 10px;
    }

    .admin-section button:hover {
      background-color: #ffcc00;
      color: #003366;
    }
    .modal-content button {
      width: 100%;
      padding: 10px;
      background-color: #00509e;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 1em;
      cursor: pointer;
      margin-top: 10px;
    }
    .modal-content button:hover {
      background-color: #ffcc00;
      color: #003366;
    }
    .close {
      color: #aaa;
      position: absolute;
      right: 10px;
      top: 5px;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    .close:hover {
      color: #000;
    }
    footer {
      background-color: #003366;
      color: white;
      text-align: center;
      padding: 10px 0;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <header>
    <h1>State Pharmaceutical Corporation</h1>
    <p>Admin Panel - Staff Management</p>
  </header>
  <nav>
    <a href="home.php">Home</a>
    <a href="about.php">About Us</a>
    <a href="services.php">Services</a>
    <a href="contact.php">Contact</a>
  </nav>
  <div class="container">
    <!-- Staff Registration Section -->
    <div class="admin-section">
      <h2>Register User</h2>
      <button onclick="openRegistrationModal()">User Register</button>
    </div>
    
    <!-- Staff Table -->
    <h2>Staff List</h2>
    <table id="staffTable">
      <thead>
        <tr>
          <th>ID</th>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Email</th>
          <th>Address</th>
          <th>Type</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <!-- Dynamic staff rows go here -->
      </tbody>
    </table>
  </div>

  <!-- Modal for Registration -->
  <div id="registerModal" class="modal">
    <div class="modal-content">
      <span class="close" id="closeRegisterModal">&times;</span>
      <h2>User Registration</h2>
      <form id="registerForm">
        <div class="form-group">
          <label for="regFirstname">First Name</label>
          <input type="text" id="regFirstname" name="firstname" placeholder="Enter First Name" required>
        </div>
        <div class="form-group">
          <label for="regLastname">Last Name</label>
          <input type="text" id="regLastname" name="lastname" placeholder="Enter Last Name" required>
        </div>
        <div class="form-group">
          <label for="regEmail">Email</label>
          <input type="email" id="regEmail" name="email" placeholder="Enter Email Address" required>
        </div>
        <div class="form-group">
          <label for="regPassword">Password</label>
          <input type="password" id="regPassword" name="password" placeholder="Enter Password" required>
        </div>
        <div class="form-group">
          <label for="regAddress">Address</label>
          <input type="text" id="regAddress" name="address" placeholder="Enter Address" required>
        </div>
        <div class="form-group">
          <label for="regType">Type</label>
          <select id="regType" name="type" required>
            <option value="">Select Type</option>
            <option value="admin">Admin</option>
            <option value="warehouse">warehouse staff</option>
            <option value="manufacture">manufacture staff</option>
            <option value="pharmacies">pharmacies</option>
          </select>
        </div>
        <button type="submit">Register</button>
      </form>
    </div>
  </div>

  <!-- Modal for Update -->
  <div id="updateModal" class="modal">
    <div class="modal-content">
      <span class="close" id="closeUpdateModal">&times;</span>
      <h2>Update Staff</h2>
      <form id="updateForm">
        <input type="hidden" id="updateId" name="id" />
        <div class="form-group">
          <label for="updateFirstname">First Name</label>
          <input type="text" id="updateFirstname" name="firstname" required>
        </div>
        <div class="form-group">
          <label for="updateLastname">Last Name</label>
          <input type="text" id="updateLastname" name="lastname" required>
        </div>
        <div class="form-group">
          <label for="updateEmail">Email</label>
          <input type="email" id="updateEmail" name="email" required>
        </div>
        <div class="form-group">
          <label for="updatePassword">Password</label>
          <input type="password" id="updatePassword" name="password" required>
        </div>
        <div class="form-group">
          <label for="updateAddress">Address</label>
          <input type="text" id="updateAddress" name="address" required>
        </div>
        <div class="form-group">
          <label for="updateType">Type</label>
          <select id="updateType" name="type" required>
            <option value="admin">Admin</option>
            <option value="employee">Employee</option>
          </select>
        </div>
        <button type="submit" class="btn btn-update">Update Staff</button>
      </form>
    </div>
  </div>

  <footer>
    <p>&copy; 2025 State Pharmaceutical Corporation. All rights reserved.</p>
  </footer>

  <script>
    // -------------------------------
    // Registration Modal Logic
    // -------------------------------
    const registerModal = document.getElementById("registerModal");
    const closeRegisterModal = document.getElementById("closeRegisterModal");

    function openRegistrationModal() {
      registerModal.style.display = "block";
    }
    closeRegisterModal.onclick = function() {
      registerModal.style.display = "none";
    }
    window.addEventListener("click", function(event) {
      if (event.target === registerModal) {
        registerModal.style.display = "none";
      }
    });

    // -------------------------------
    // Registration Form Submission Logic
    // -------------------------------
    document.getElementById("registerForm").addEventListener("submit", function(e) {
      e.preventDefault();
      const newStaff = {
        firstname: document.getElementById("regFirstname").value,
        lastname: document.getElementById("regLastname").value,
        email: document.getElementById("regEmail").value,
        password: document.getElementById("regPassword").value,
        address: document.getElementById("regAddress").value,
        type: document.getElementById("regType").value
      };

      fetch("https://localhost:7123/api/Staff", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newStaff)
      })
      .then(response => {
        if (response.ok) {
          alert("Staff added successfully.");
          registerModal.style.display = "none";
          document.getElementById("registerForm").reset();
          fetchStaffs();
        } else {
          alert("Error adding staff.");
        }
      })
      .catch(error => {
        console.error("Error adding staff:", error);
        alert("Error adding staff.");
      });
    });

    // -------------------------------
    // Fetch and Display Staff Table
    // -------------------------------
    function fetchStaffs() {
      fetch('https://localhost:7123/api/Staff')
        .then(response => response.json())
        .then(data => {
          const tbody = document.querySelector('#staffTable tbody');
          tbody.innerHTML = "";
          data.forEach(staff => {
            const row = document.createElement("tr");
            row.innerHTML = `
              <td>${staff.id}</td>
              <td>${staff.firstname}</td>
              <td>${staff.lastname}</td>
              <td>${staff.email}</td>
              <td>${staff.address}</td>
              <td>${staff.type}</td>
              <td>
                <button class="btn btn-update" onclick="openUpdateModal(${staff.id})">Update</button>
                <button class="btn btn-delete" onclick="deleteStaff(${staff.id})">Delete</button>
              </td>
            `;
            tbody.appendChild(row);
          });
        })
        .catch(error => console.error("Error fetching staff:", error));
    }

    // -------------------------------
    // Delete Staff
    // -------------------------------
    function deleteStaff(id) {
      if (!confirm("Are you sure you want to delete this staff member?")) return;
      fetch(`https://localhost:7123/api/Staff/${id}`, {
        method: "DELETE"
      })
      .then(response => {
        if(response.ok) {
          alert("Staff deleted successfully.");
          fetchStaffs();
        } else {
          alert("Error deleting staff.");
        }
      })
      .catch(error => {
        console.error("Error deleting staff:", error);
        alert("Error deleting staff.");
      });
    }

    // -------------------------------
    // Update Modal Logic
    // -------------------------------
    const updateModal = document.getElementById("updateModal");
    const closeUpdateModal = document.getElementById("closeUpdateModal");

    function openUpdateModal(id) {
      fetch(`https://localhost:7123/api/Staff/${id}`)
        .then(response => response.json())
        .then(staff => {
          document.getElementById("updateId").value = staff.id;
          document.getElementById("updateFirstname").value = staff.firstname;
          document.getElementById("updateLastname").value = staff.lastname;
          document.getElementById("updateEmail").value = staff.email;
          document.getElementById("updatePassword").value = staff.password;
          document.getElementById("updateAddress").value = staff.address;
          document.getElementById("updateType").value = staff.type;
          updateModal.style.display = "block";
        })
        .catch(error => console.error("Error fetching staff details:", error));
    }
    closeUpdateModal.onclick = function() {
      updateModal.style.display = "none";
    }
    window.addEventListener("click", function(event) {
      if (event.target === updateModal) {
        updateModal.style.display = "none";
      }
    });

    // -------------------------------
    // Handle Update Form Submission
    // -------------------------------
    document.getElementById("updateForm").addEventListener("submit", function(e) {
      e.preventDefault();
      const id = document.getElementById("updateId").value;
      const staff = {
        id: parseInt(id),
        firstname: document.getElementById("updateFirstname").value,
        lastname: document.getElementById("updateLastname").value,
        email: document.getElementById("updateEmail").value,
        password: document.getElementById("updatePassword").value,
        address: document.getElementById("updateAddress").value,
        type: document.getElementById("updateType").value
      };

      fetch("https://localhost:7123/api/Staff", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(staff)
      })
      .then(response => {
        if (response.ok) {
          alert("Staff updated successfully.");
          updateModal.style.display = "none";
          fetchStaffs();
        } else {
          alert("Error updating staff.");
        }
      })
      .catch(error => {
        console.error("Error updating staff:", error);
        alert("Error updating staff.");
      });
    });

    // Initial load
    fetchStaffs();
  </script>
</body>
</html>
