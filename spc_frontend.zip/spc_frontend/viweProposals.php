<?php
session_start();
if (!isset($_SESSION['Email'])) {
    header("Location: index.php"); // Redirect if not logged in
    exit();
}

$userType = $_SESSION['UserType'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - State Pharmaceutical Corporation</title>
    <style>
            body {
                margin: 0;
                font-family: Arial, sans-serif;
                background-color: #f4f8fb;
                color: #333;
            }
            header {
                background-color: #003366;
                color: white;
                padding: 20px 10%;
                text-align: center;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
            header h1 {
                margin: 0;
                font-size: 2.5em;
            }
            header p {
                margin: 5px 0 0;
                font-size: 1.2em;
            }
            nav {
                display: flex;
                justify-content: center;
                background-color: #00509e;
                padding: 10px 0;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }
            nav a {
                color: white;
                text-decoration: none;
                margin: 0 15px;
                font-size: 1.1em;
                font-weight: bold;
                transition: color 0.3s;
            }
            nav a:hover {
                color: #ffcc00;
            }
            .container {
                padding: 20px 10%;
            }
            .admin-section {
                background-color: white;
                border-radius: 10px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                padding: 20px;
                margin-top: 20px;
            }
            .admin-section h2 {
                color: #003366;
                margin-bottom: 20px;
            }
            .admin-section button {
                background-color: #00509e;
                color: white;
                border: none;
                padding: 10px 20px;
                font-size: 1em;
                border-radius: 5px;
                cursor: pointer;
                margin: 5px 0;
                display: block;
                width: 100%;
                transition: background-color 0.3s;
            }
            .admin-section button:hover {
                background-color: #ffcc00;
                color: #003366;
            }
            .admin-section .logout {
                background-color: #00509e;
                color: white;
                border: none;
                padding: 10px 20px;
                font-size: 1em;
                border-radius: 5px;
                cursor: pointer;
                margin: 5px 0;
                display: block;
                width: 10%;
                transition: background-color 0.3s;
            }
            .admin-section .logout:hover {
                background-color: #ffcc00;
                color: #003366;
            }
            .admin-section .form-group {
                margin-bottom: 15px;
            }
            .admin-section label {
                font-weight: bold;
                display: block;
                margin: 10px 0 5px;
            }
            .admin-section input, .admin-section select, .admin-section textarea {
                width: 100%;
                padding: 10px;
                border: 1px solid #ccc;
                border-radius: 5px;
                font-size: 1em;
            }
            footer {
                background-color: #003366;
                color: white;
                text-align: center;
                padding: 10px 0;
                margin-top: 20px;
            }

            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
                background-color: white;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                border-radius: 10px;
                overflow: hidden;
            }

            th, td {
                padding: 12px;
                text-align: left;
                border-bottom: 1px solid #ddd;
            }

            th {
                background-color: #00509e;
                color: white;
                font-size: 1.1em;
            }

            td {
                font-size: 1em;
                color: #333;
            }

            tr:hover {
                background-color: #f4f8fb;
                transition: background-color 0.3s ease;
            }

            tbody tr:last-child td {
                border-bottom: none;
            }

            @media (max-width: 768px) {
                th, td {
                    padding: 10px;
                    font-size: 0.9em;
                }
            }

    </style>
</head>
<body>
    <header>
        <h1>State Pharmaceutical Corporation</h1>
        <!-- <p>Admin Panel</p> -->
    </header>
    <nav>
        <a href="home.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="services.php">Services</a>
        <a href="contact.php">Contact</a>
    </nav>
    <div class="container">
        <div class="admin-section">
        <button class="logout" onclick="location.href='logout.php'">Logout</button>

            <h2>Welcome</h2>

            <h2>Tender Proposals</h2>
            <table border="1" id="tenderTable">
                <thead>
                    <tr>
                        <th>Supplier Name</th>
                        <th>Supplier Email</th>
                        <th>Drug Name</th>
                        <th>Drug Quantity</th>
                        <th>Details</th>
                        <th>Drug Price</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Data will be inserted here -->
                </tbody>
            </table>

           
        </div>
    </div>
    <footer>
        <p>&copy; 2025 State Pharmaceutical Corporation. All rights reserved.</p>
    </footer>

    <script>
    document.addEventListener("DOMContentLoaded", function () {
        fetch("https://localhost:7123/api/TederProposalSubmit/all")
            .then(response => response.json())
            .then(data => {
                let tableBody = document.querySelector("#tenderTable tbody");
                tableBody.innerHTML = ""; // Clear existing rows
                
                data.forEach(proposal => {
                    let row = `<tr>
                        <td>${proposal.supplierName}</td>
                        <td>${proposal.supplierEmail}</td>
                        <td>${proposal.drugName}</td>
                        <td>${proposal.drugQuantity}</td>
                        <td>${proposal.details || "N/A"}</td>
                        <td>${proposal.drugPrice}</td>
                    </tr>`;
                    tableBody.innerHTML += row;
                });
            })
            .catch(error => console.error("Error fetching data:", error));
    });
    </script>

</body>
</html>