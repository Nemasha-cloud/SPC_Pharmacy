<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["EMAIL"] ?? '';
    $password = $_POST["PASSWORD"] ?? '';

    $data = array(
        "email" => $email,
        "password" => $password
    );

    $ch = curl_init();
    $url = "https://localhost:7123/api/Staff/login"; // API Endpoint

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));

    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode == 200) {
        $response_data = json_decode($response, true);
        
        if ($response_data['status'] == "success") {
            $_SESSION['Email'] = $email;
            $_SESSION['UserType'] = $response_data['data']['type']; // Store staff type
            header("Location: staff.php"); // Redirect to dashboard
            exit();
        } else {
            echo '<script>alert("Invalid credentials. Please try again.");</script>';
        }
    } else {
        echo '<script>alert("Login failed. Please check your details.");</script>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Login</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #74b9ff, #0984e3);
            color: #fff;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background: #fff;
            color: #2d3436;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 450px;
            animation: fadeIn 1s ease-in-out;
        }
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #0984e3;
        }
        .form-group {
            margin-bottom: 20px;
        }
        .form-container label {
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
            color: #636e72;
        }
        .form-container input {
            width: 100%;
            padding: 12px;
            font-size: 16px;
            border: 1px solid #dfe6e9;
            border-radius: 8px;
            outline: none;
            transition: all 0.3s ease;
            line-height: 1.5;
            box-sizing: border-box;
        }
        .form-container input::placeholder {
            font-size: 14px;
            color: #b2bec3;
        }
        .form-container input:focus {
            border-color: #0984e3;
            box-shadow: 0 0 5px rgba(9, 132, 227, 0.5);
        }
        .form-container button {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            background-color: #0984e3;
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .form-container button:hover {
            background-color: #74b9ff;
            transform: scale(1.05);
        }
        .form-container .Sup {
            width: 21%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            background-color:rgb(2, 143, 96);
            color: #fff;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .form-container .Sup:hover {
            background-color: #74b9ff;
            transform: scale(1.05);
        }
        .form-container button:active {
            transform: scale(0.95);
        }
    </style>
</head>
<body>
    <div class="form-container">
        
    <button class="Sup" onclick="location.href='supplierLogin.php'">Supplier Login</button>  
        <h2>Staff Login</h2>
        <form method="POST" action="">
            <div class="form-group">
                <label for="EMAIL">Email</label>
                <input type="email" id="EMAIL" name="EMAIL" placeholder="Enter Email Address" required>
            </div>
            <div class="form-group">
                <label for="PASSWORD">Password</label>
                <input type="password" id="PASSWORD" name="PASSWORD" placeholder="Enter Password" required>
            </div>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
