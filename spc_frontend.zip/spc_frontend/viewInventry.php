<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Drug Inventory - Tender Request</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background: #f4f8fb;
      color: #333;
    }
    header {
      background: #003366;
      color: white;
      padding: 20px 10%;
      text-align: center;
    }
    .container {
      padding: 20px 10%;
    }
    h2 {
      color: #003366;
    }
    /* Search Bar */
    .search-bar {
      margin-bottom: 20px;
    }
    .search-bar input {
      width: 100%;
      padding: 10px;
      font-size: 1em;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }
    /* Table Styles */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    table, th, td {
      border: 1px solid #ddd;
    }
    th, td {
      padding: 10px;
      text-align: left;
    }
    th {
      background: #003366;
      color: white;
    }
    tr:nth-child(even) {
      background: #f2f2f2;
    }
    .btn {
      padding: 5px 10px;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      margin-right: 5px;
    }
    .btn-request {
      background: #e67e22;
      color: white;
    }
    /* Modal Styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 2;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background: rgba(0, 0, 0, 0.5);
    }
    .modal-content {
      background: #fff;
      margin: 10% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 40%;
      border-radius: 10px;
      position: relative;
    }
    .modal-content h2 {
      margin-bottom: 15px;
      text-align: center;
      color: #003366;
    }
    .modal-content .form-group {
      margin-bottom: 15px;
    }
    .modal-content label {
      font-weight: bold;
      display: block;
      margin-bottom: 5px;
    }
    .modal-content input {
      width: 100%;
      padding: 8px;
      box-sizing: border-box;
    }
    .modal-content button {
      width: 100%;
      padding: 10px;
      background: #003366;
      color: white;
      border: none;
      border-radius: 5px;
      margin-top: 10px;
      cursor: pointer;
    }
    .close {
      position: absolute;
      right: 10px;
      top: 5px;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
      color: #aaa;
    }
    .close:hover { color: #000; }
    footer {
      background: #003366;
      color: white;
      text-align: center;
      padding: 10px 0;
      margin-top: 20px;
    }
  </style>
</head>
<body>
  <header>
    <h1>Drug Inventory</h1>
    <p>View Availability & Request Tender Proposals</p>
  </header>
  <div class="container">
    <!-- Search Bar -->
    <div class="search-bar">
      <input type="text" id="searchInput" placeholder="Search drugs by name..." onkeyup="searchDrugs()">
    </div>
    
    <!-- Drug Inventory Table -->
    <table id="drugTable">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Description</th>
          <th>Quantity</th>
          <th>Status</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <!-- Drug rows will be inserted here dynamically -->
      </tbody>
    </table>

    

        <!-- Add this inside the container div below the drug inventory table -->
    <h2>Submitted Tender Proposals</h2>
    <table id="tenderTable">
    <thead>
        <tr>
        <th>ID</th>
        <th>Drug Name</th>
        <th>Requested Quantity</th>
        <th>Contact Email</th>
        </tr>
    </thead>
    <tbody>
        <!-- Tender proposal rows will be inserted here dynamically -->
    </tbody>
    </table>


  </div>

  <!-- Order Modal -->
  <div id="orderModal" class="modal">
      <div class="modal-content">
          <span class="close" id="closeOrderModal">&times;</span>
          <h2>Place an Order</h2>
          <form id="orderForm">
              <!-- Hidden field for drug id -->
              <input type="hidden" id="orderDrugId" name="drugId">
              <div class="form-group">
                  <label for="orderDrugName">Drug Name</label>
                  <input type="text" id="orderDrugName" name="drugName" readonly>
              </div>
              <div class="form-group">
                  <label for="orderQuantity">Quantity</label>
                  <input type="number" id="orderQuantity" name="quantity" min="1" required>
              </div>
              <button type="submit">Submit Order</button>
          </form>
      </div>
  </div>

  

  <!-- Tender Proposal Modal -->
  <div id="tenderModal" class="modal">
    <div class="modal-content">
      <span class="close" id="closeTenderModal">&times;</span>
      <h2>Request Tender Proposal</h2>
      <form id="tenderForm">
        <!-- Hidden field for drug id -->
        <input type="hidden" id="tenderDrugId" name="drugId">
        <div class="form-group">
          <label for="tenderDrugName">Drug Name</label>
          <input type="text" id="tenderDrugName" name="drugName" readonly>
        </div>
        <div class="form-group">
          <label for="tenderQuantity">Requested Quantity</label>
          <input type="number" id="tenderQuantity" name="requestedQuantity" placeholder="Enter required quantity" required>
        </div>
        <div class="form-group">
          <label for="tenderEmail">Your Email</label>
          <input type="email" id="tenderEmail" name="contactEmail" placeholder="Enter your email" required>
        </div>
        <button type="submit">Submit Proposal</button>
      </form>
    </div>
  </div>

  <footer>
    <p>&copy; 2025 State Pharmaceutical Corporation. All rights reserved.</p>
  </footer>

  <script>
  // ---------------------------
  // Fetch and Display Tender Proposals
  // ---------------------------
  function fetchTenderProposals() {
    fetch("https://localhost:7123/api/tenderproposal")
      .then(response => response.json())
      .then(data => {
        displayTenderProposals(data);
      })
      .catch(error => console.error("Error fetching tender proposals:", error));
  }

  function displayTenderProposals(proposals) {
    const tbody = document.querySelector("#tenderTable tbody");
    tbody.innerHTML = "";
    proposals.forEach(proposal => {
      const row = document.createElement("tr");
      row.innerHTML = `
        <td>${proposal.id}</td>
        <td>${proposal.drugName}</td>
        <td>${proposal.requestedQuantity}</td>
        <td>${proposal.contactEmail}</td>
      `;
      tbody.appendChild(row);
    });
  }

  // Fetch tender proposals on page load
  fetchTenderProposals();
</script>


  <script>
    // ---------------------------
    // Global Variables & Modal Logic
    // ---------------------------
    const tenderModal = document.getElementById("tenderModal");
    const closeTenderModal = document.getElementById("closeTenderModal");

    closeTenderModal.onclick = () => { tenderModal.style.display = "none"; };
    window.addEventListener("click", event => {
      if (event.target === tenderModal) { tenderModal.style.display = "none"; }
    });

    // ---------------------------
    // Fetch and Display Drugs
    // ---------------------------
    let allDrugs = []; // Global array to store fetched drugs

    function fetchDrugs() {
      fetch("https://localhost:7123/api/Drug")
        .then(response => response.json())
        .then(data => {
          allDrugs = data;
          displayDrugs(data);
        })
        .catch(error => console.error("Error fetching drugs:", error));
    }

    function displayDrugs(drugs) {
      const tbody = document.querySelector("#drugTable tbody");
      tbody.innerHTML = "";
      drugs.forEach(drug => {
        const status = drug.quantity > 0 ? "Available" : "Not Available";
        // If not available, show tender button.
        let actions = "";
        if (drug.quantity > 0) {
          actions = ` <button class="btn btn-order" onclick="openOrderModal(${drug.id}, '${drug.name}')">Place an Order</button>`;
        } else {
          actions = `<button class="btn btn-request" onclick="openTenderModal(${drug.id}, '${drug.name}')">Request Tender Proposal</button>`;
        }
        const row = document.createElement("tr");
        row.innerHTML = `
          <td>${drug.id}</td>
          <td>${drug.name}</td>
          <td>${drug.description}</td>
          <td>${drug.quantity}</td>
          <td>${status}</td>
          <td>${actions}</td>
        `;
        tbody.appendChild(row);
      });
    }

    // ---------------------------
    // Search Functionality
    // ---------------------------
    function searchDrugs() {
      const searchValue = document.getElementById("searchInput").value.toLowerCase();
      const filteredDrugs = allDrugs.filter(drug => 
        drug.name.toLowerCase().includes(searchValue)
      );
      displayDrugs(filteredDrugs);
    }

    // ---------------------------
    // Open Tender Proposal Modal
    // ---------------------------
    function openTenderModal(drugId, drugName) {
      document.getElementById("tenderDrugId").value = drugId;
      document.getElementById("tenderDrugName").value = drugName;
      tenderModal.style.display = "block";
    }

    // ---------------------------
    // Tender Proposal Form Submission
    // ---------------------------
    document.getElementById("tenderForm").addEventListener("submit", function(e) {
      e.preventDefault();
      const proposal = {
        drugId: parseInt(document.getElementById("tenderDrugId").value),
        drugName: document.getElementById("tenderDrugName").value,
        requestedQuantity: parseInt(document.getElementById("tenderQuantity").value),
        contactEmail: document.getElementById("tenderEmail").value
      };

      fetch("https://localhost:7123/api/tenderproposal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(proposal)
      })
      .then(response => {
        if (response.ok) {
          alert("Tender proposal submitted successfully.");
          tenderModal.style.display = "none";
          document.getElementById("tenderForm").reset();
        } else {
          alert("Error submitting tender proposal.");
        }
      })
      .catch(error => {
        console.error("Error submitting proposal:", error);
        alert("Error submitting proposal.");
      });
    });

    // ---------------------------
    // Initial Load
    // ---------------------------
    fetchDrugs();
  </script>

<script>
    // Order Modal Logic
    const orderModal = document.getElementById("orderModal");
    const closeOrderModal = document.getElementById("closeOrderModal");

    closeOrderModal.onclick = () => { orderModal.style.display = "none"; };
    window.addEventListener("click", event => {
        if (event.target === orderModal) { orderModal.style.display = "none"; }
    });

    function openOrderModal(drugId, drugName) {
        document.getElementById("orderDrugId").value = drugId;
        document.getElementById("orderDrugName").value = drugName;
        orderModal.style.display = "block";
    }

    // Handle Order Submission
    document.getElementById("orderForm").addEventListener("submit", function(e) {
        e.preventDefault();
        const order = {
            drugId: parseInt(document.getElementById("orderDrugId").value),
            drugName: document.getElementById("orderDrugName").value,
            quantity: parseInt(document.getElementById("orderQuantity").value)
        };

        fetch("https://localhost:7123/api/order", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(order)
        })
        .then(response => {
            if (response.ok) {
                alert("Order placed successfully.");
                orderModal.style.display = "none";
                document.getElementById("orderForm").reset();
            } else {
                alert("Error placing order.");
            }
        })
        .catch(error => {
            console.error("Error submitting order:", error);
            alert("Error placing order.");
        });
    });
    </script>
</body>
</html>
