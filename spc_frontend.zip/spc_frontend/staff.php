<?php
session_start();
if (!isset($_SESSION['Email'])) {
    header("Location: index.php");
    exit();
}

$userType = $_SESSION['UserType'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - State Pharmaceutical Corporation</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f8fb;
            color: #333;
        }
        header {
            background-color:rgb(11, 107, 203);
            color: white;
            padding: 20px 10%;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        nav {
            display: flex;
            justify-content: center;
            background-color:rgb(38, 38, 38);
            padding: 10px 0;
        }
        nav a {
            color: white;
            text-decoration: none;
            margin: 0 15px;
            font-size: 1.1em;
            font-weight: bold;
            transition: color 0.3s;
        }
        nav a:hover {
            color: #ffcc00;
        }
        .container {
            padding: 71px 14%;
            display: flex;
            /* flex-wrap: wrap; */
            justify-content: center;
            gap: 20px;
        }
        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            text-align: center;
            width: 250px;
            cursor: pointer;
            transition: transform 0.3s, background-color 0.3s;
        }
        .card:hover {
            transform: scale(1.05);
            background-color: #ffcc00;
            color: #003366;
        }
        .logout {
            background-color: #d9534f;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 1em;
            border-radius: 5px;
            cursor: pointer;
            display: block;
            margin: 20px auto;
            width: 150px;
            transition: background-color 0.3s;
        }
        .logout:hover {
            background-color: #c9302c;
        }
        footer {
            background-color: #003366;
            color: white;
            text-align: center;
            padding: 10px 0;
            margin-top: 453px;
        }
    </style>
</head>
<body>
    <header>
        <h1>State Pharmaceutical Corporation</h1>
    </header>
    <nav>
        <a href="home.php">Home</a>
        <a href="about.php">About Us</a>
        <a href="services.php">Services</a>
        <a href="contact.php">Contact</a>
    </nav>
    <div class="container">
        <button class="logout" onclick="location.href='logout.php'">Logout</button>
        
        <?php if ($userType === 'admin') { ?>
            <div class="card" onclick="location.href='supplierRegister.php'">Supplier Register</div>
            <div class="card" onclick="location.href='drugManagement.php'">Drug Management</div>
            <div class="card" onclick="location.href='viewInventry.php'">View Inventory</div>
            <div class="card" onclick="location.href='viweProposals.php'">View Supplier Tender Proposals</div>
            <div class="card" onclick="location.href='createstaffmember.php'">Create/Register User Account</div>
        <?php } elseif ($userType === 'warehouse' || $userType === 'manufacture') { ?>
            <div class="card" onclick="location.href='drugManagement.php'">Drug Management</div>
            <div class="card" onclick="location.href='viewInventry.php'">View Inventory</div>
        <?php } elseif ($userType === 'pharmacies') { ?>
            <div class="card" onclick="location.href='viewInventry.php'">View Inventory</div>
            <div class="card" onclick="location.href='viweProposals.php'">View Supplier Tender Proposals</div>
        <?php } ?>
    </div>
    <footer>
        <p>&copy; 2025 State Pharmaceutical Corporation. All rights reserved.</p>
    </footer>
</body>
</html>