<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Admin Panel - Supplier Management</title>
  <style>
    body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #f4f8fb;
      color: #333;
    }
    header {
      background-color: #003366;
      color: white;
      padding: 20px 10%;
      text-align: center;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    nav {
      display: flex;
      justify-content: center;
      background-color: #00509e;
      padding: 10px 0;
      box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    nav a {
      color: white;
      text-decoration: none;
      margin: 0 15px;
      font-size: 1.1em;
      font-weight: bold;
      transition: color 0.3s;
    }
    nav a:hover {
      color: #ffcc00;
    }
    .container {
      padding: 20px 10%;
    }
    h2 {
      color: #003366;
    }
    /* Table styling */
    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    table, th, td {
      border: 1px solid #ddd;
    }
    th, td {
      padding: 10px;
      text-align: left;
    }
    th {
      background-color: #003366;
      color: #fff;
    }
    tr:nth-child(even) {
      background-color: #f2f2f2;
    }
    .btn {
      padding: 5px 10px;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      margin-right: 5px;
    }
    .btn-update { background-color: #4CAF50; color: white; }
    .btn-delete { background-color: #f44336; color: white; }
    .btn-approve { background-color: #008CBA; color: white; }
    .btn-unapprove { background-color: #e7e700; color: black; }
    /* Modal Styles */
    .modal {
      display: none;
      position: fixed;
      z-index: 2;
      left: 0;
      top: 0;
      width: 100%;
      height: 100%;
      overflow: auto;
      background-color: rgba(0,0,0,0.5);
    }
    .modal-content {
      background-color: #fff;
      margin: 10% auto;
      padding: 20px;
      border: 1px solid #888;
      width: 40%;
      border-radius: 10px;
      position: relative;
    }
    .modal-content h2 {
      color: #003366;
      margin-bottom: 15px;
      text-align: center;
    }
    .modal-content .form-group {
      margin-bottom: 15px;
    }
    .modal-content label {
      font-weight: bold;
      display: block;
      margin-bottom: 5px;
    }
    .modal-content input,
    .modal-content select {
      width: 100%;
      padding: 8px;
      box-sizing: border-box;
    }
    .modal-content button {
      width: 100%;
      padding: 10px;
      background-color: #00509e;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 1em;
      cursor: pointer;
      margin-top: 10px;
    }
    .modal-content button:hover {
      background-color: #ffcc00;
      color: #003366;
    }
    .close {
      color: #aaa;
      position: absolute;
      right: 10px;
      top: 5px;
      font-size: 28px;
      font-weight: bold;
      cursor: pointer;
    }
    .close:hover { color: #000; }
    footer {
      background-color: #003366;
      color: white;
      text-align: center;
      padding: 10px 0;
      margin-top: 300px;
    }

    .admin-section button {
      width: 20%;
      padding: 10px;
      background-color: #00509e;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 1em;
      cursor: pointer;
      margin-top: 10px;
    }

    .admin-section button:hover {
      background-color: #ffcc00;
      color: #003366;
    }
  </style>
</head>
<body>
  <header>
    <h1>State Pharmaceutical Corporation</h1>
    <p>Admin Panel - Supplier Management</p>
  </header>
  <nav>
    <a href="home.php">Home</a>
    <a href="about.php">About Us</a>
    <a href="services.php">Services</a>
    <a href="contact.php">Contact</a>
  </nav>
  <div class="container">
    <!-- Supplier Registration Section -->
    <div class="admin-section">
      <h2>Supplier Register</h2>
      <button onclick="openRegisterModal()">Supplier Register</button>
    </div>

    <!-- Supplier Table -->
    <h2>Supplier List</h2>
    <table id="supplierTable">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Supplied Item</th>
          <th>Quantity</th>
          <th>Address</th>
          <th>Approved</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <!-- Dynamic supplier rows will be inserted here -->
      </tbody>
    </table>
  </div>

  <!-- Registration Modal -->
  <div id="registerModal" class="modal">
    <div class="modal-content">
      <span class="close" id="closeRegisterModal">&times;</span>
      <h2>Supplier Registration</h2>
      <form id="registerForm">
        <div class="form-group">
          <label for="regName">Name</label>
          <input type="text" id="regName" name="name" placeholder="Enter Name" required>
        </div>
        <div class="form-group">
          <label for="regEmail">Email</label>
          <input type="email" id="regEmail" name="email" placeholder="Enter Email" required>
        </div>
        <div class="form-group">
          <label for="regPassword">Password</label>
          <input type="password" id="regPassword" name="password" placeholder="Enter Password" required>
        </div>
        <div class="form-group">
          <label for="regSuppliedItem">Supplied Item</label>
          <input type="text" id="regSuppliedItem" name="suppliedItem" placeholder="Enter Supplied Item" required>
        </div>
        <div class="form-group">
          <label for="regQuantity">Quantity</label>
          <input type="text" id="regQuantity" name="quantity" placeholder="Enter Quantity" required>
        </div>
        <div class="form-group">
          <label for="regAddress">Address</label>
          <input type="text" id="regAddress" name="address" placeholder="Enter Address" required>
        </div>
        <button type="submit">Register Supplier</button>
      </form>
    </div>
  </div>

  <!-- Update Modal -->
  <div id="updateModal" class="modal">
    <div class="modal-content">
      <span class="close" id="closeUpdateModal">&times;</span>
      <h2>Update Supplier</h2>
      <form id="updateForm">
        <input type="hidden" id="updateId" name="id" />
        <div class="form-group">
          <label for="updateName">Name</label>
          <input type="text" id="updateName" name="name" required>
        </div>
        <div class="form-group">
          <label for="updateEmail">Email</label>
          <input type="email" id="updateEmail" name="email" required>
        </div>
        <div class="form-group">
          <label for="updatePassword">Password</label>
          <input type="password" id="updatePassword" name="password" required>
        </div>
        <div class="form-group">
          <label for="updateSuppliedItem">Supplied Item</label>
          <input type="text" id="updateSuppliedItem" name="suppliedItem" required>
        </div>
        <div class="form-group">
          <label for="updateQuantity">Quantity</label>
          <input type="text" id="updateQuantity" name="quantity" required>
        </div>
        <div class="form-group">
          <label for="updateAddress">Address</label>
          <input type="text" id="updateAddress" name="address" required>
        </div>
        <button type="submit">Update Supplier</button>
      </form>
    </div>
  </div>

  <footer>
    <p>&copy; 2025 State Pharmaceutical Corporation. All rights reserved.</p>
  </footer>

  <script>
    // -------------------------
    // Modal Logic for Registration
    // -------------------------
    const registerModal = document.getElementById("registerModal");
    const closeRegisterModal = document.getElementById("closeRegisterModal");

    function openRegisterModal() {
      registerModal.style.display = "block";
    }
    closeRegisterModal.onclick = () => registerModal.style.display = "none";
    window.addEventListener("click", event => {
      if (event.target === registerModal) registerModal.style.display = "none";
    });

    // -------------------------
    // Modal Logic for Update
    // -------------------------
    const updateModal = document.getElementById("updateModal");
    const closeUpdateModal = document.getElementById("closeUpdateModal");

    function openUpdateModal(id) {
      // Fetch supplier data by ID
      fetch(`https://localhost:7123/api/supplier/${id}`)
        .then(response => response.json())
        .then(supplier => {
          document.getElementById("updateId").value = supplier.id;
          document.getElementById("updateName").value = supplier.name;
          document.getElementById("updateEmail").value = supplier.email;
          document.getElementById("updatePassword").value = supplier.password;
          document.getElementById("updateSuppliedItem").value = supplier.suppliedItem;
          document.getElementById("updateQuantity").value = supplier.quantity;
          document.getElementById("updateAddress").value = supplier.address;
          updateModal.style.display = "block";
        })
        .catch(error => console.error("Error fetching supplier details:", error));
    }
    closeUpdateModal.onclick = () => updateModal.style.display = "none";
    window.addEventListener("click", event => {
      if (event.target === updateModal) updateModal.style.display = "none";
    });

    // -------------------------
    // Registration Form Submission
    // -------------------------
    document.getElementById("registerForm").addEventListener("submit", function(e) {
      e.preventDefault();
      const newSupplier = {
        name: document.getElementById("regName").value,
        email: document.getElementById("regEmail").value,
        password: document.getElementById("regPassword").value,
        suppliedItem: document.getElementById("regSuppliedItem").value,
        quantity: document.getElementById("regQuantity").value,
        address: document.getElementById("regAddress").value
      };

      fetch("https://localhost:7123/api/supplier", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newSupplier)
      })
      .then(response => {
        if (response.ok) {
          alert("Supplier added successfully.");
          registerModal.style.display = "none";
          document.getElementById("registerForm").reset();
          fetchSuppliers();
        } else {
          alert("Error adding supplier.");
        }
      })
      .catch(error => {
        console.error("Error adding supplier:", error);
        alert("Error adding supplier.");
      });
    });

    // -------------------------
    // Update Form Submission
    // -------------------------
    document.getElementById("updateForm").addEventListener("submit", function(e) {
      e.preventDefault();
      const supplier = {
        id: parseInt(document.getElementById("updateId").value),
        name: document.getElementById("updateName").value,
        email: document.getElementById("updateEmail").value,
        password: document.getElementById("updatePassword").value,
        suppliedItem: document.getElementById("updateSuppliedItem").value,
        quantity: document.getElementById("updateQuantity").value,
        address: document.getElementById("updateAddress").value
      };

      fetch("https://localhost:7123/api/supplier", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(supplier)
      })
      .then(response => {
        if (response.ok) {
          alert("Supplier updated successfully.");
          updateModal.style.display = "none";
          fetchSuppliers();
        } else {
          alert("Error updating supplier.");
        }
      })
      .catch(error => {
        console.error("Error updating supplier:", error);
        alert("Error updating supplier.");
      });
    });

    // -------------------------
    // Delete Supplier
    // -------------------------
    function deleteSupplier(id) {
      if (!confirm("Are you sure you want to delete this supplier?")) return;
      fetch(`https://localhost:7123/api/supplier/${id}`, { method: "DELETE" })
        .then(response => {
          if (response.ok) {
            alert("Supplier deleted successfully.");
            fetchSuppliers();
          } else {
            alert("Error deleting supplier.");
          }
        })
        .catch(error => {
          console.error("Error deleting supplier:", error);
          alert("Error deleting supplier.");
        });
    }

    // -------------------------
    // Approve Supplier
    // -------------------------
    function approveSupplier(id) {
      fetch(`https://localhost:7123/api/supplier/approve/${id}`, { method: "PUT" })
        .then(response => {
          if (response.ok) {
            alert("Supplier approved.");
            fetchSuppliers();
          } else {
            alert("Error approving supplier.");
          }
        })
        .catch(error => {
          console.error("Error approving supplier:", error);
          alert("Error approving supplier.");
        });
    }

    // -------------------------
    // Unapprove Supplier
    // -------------------------
    function unapproveSupplier(id) {
      fetch(`https://localhost:7123/api/supplier/unapprove/${id}`, { method: "PUT" })
        .then(response => {
          if (response.ok) {
            alert("Supplier unapproved.");
            fetchSuppliers();
          } else {
            alert("Error unapproving supplier.");
          }
        })
        .catch(error => {
          console.error("Error unapproving supplier:", error);
          alert("Error unapproving supplier.");
        });
    }

    // -------------------------
    // Fetch and Display Suppliers
    // -------------------------
    function fetchSuppliers() {
      fetch("https://localhost:7123/api/supplier")
        .then(response => response.json())
        .then(data => {
          const tbody = document.querySelector("#supplierTable tbody");
          tbody.innerHTML = "";
          data.forEach(supplier => {
            const row = document.createElement("tr");
            row.innerHTML = `
              <td>${supplier.id}</td>
              <td>${supplier.name}</td>
              <td>${supplier.email}</td>
              <td>${supplier.suppliedItem}</td>
              <td>${supplier.quantity}</td>
              <td>${supplier.address}</td>
              <td>${supplier.isApproved ? "Yes" : "No"}</td>
              
              <td>
                <button class="btn btn-update" onclick="openUpdateModal(${supplier.id})">Update</button>
                <button class="btn btn-delete" onclick="deleteSupplier(${supplier.id})">Delete</button>
                <button class="btn btn-approve" onclick="approveSupplier(${supplier.id})">Approve</button>
                <button class="btn btn-unapprove" onclick="unapproveSupplier(${supplier.id})">Unapprove</button>
              </td>
            `;
            tbody.appendChild(row);
          });
        })
        .catch(error => console.error("Error fetching suppliers:", error));
    }

    // Initial load
    fetchSuppliers();
  </script>
</body>
</html>
